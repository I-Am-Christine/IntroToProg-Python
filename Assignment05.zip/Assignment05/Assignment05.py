# -------------------------------------------------#
# Title: Working with Dictionaries
# Dev:   Christine Tanner
# Date:  April 28, 2019
# ChangeLog: (Who, When, What)
#   RRoot, 11/02/2016, Created starting template
#   CTanner, Copied template (Assignment05 Starter)
#   CTanner, 5/4/2019, Added code to complete assignment 5
# -------------------------------------------------#

#---DATA----#
#Declare Variables
objFileName = "Todo.txt"
dicRow = {}
lstTable = []

# Step 1 - Load data from a file

objF = open('ToDo.txt', "r")
for line in objF:
    strTask = line.split(",")
    strPriority = line.split(",")
    dicRow = {"Task":strTask[0],"Priority":strPriority[1].strip("\n")}
    lstTable.append(dicRow)
objF.close()

def showCurrentItems():
    print("**********")
    print("The current ToDo Items are: ")
    print("**********")
    print("TASK", "(","PRIORITY",")")
    print("**********")
    for k in lstTable:
        print(k.get("Task"), "(",k.get("Priority"),")")


# Step 2 - Display a menu of choices to the user
# CETD - Please note, original starter file had options 1 to 4, in reality it's 1 to 5
while (True):
    print("""
    Menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File
    5) Exit Program
    """)
    strChoice = str(input("Which option would you like to perform? [1 to 5] - "))
    print()  # adding a new line

    # Step 3 -Show the current items in the table
    if (strChoice.strip() == '1'):

        showCurrentItems()

        continue

    # Step 4 - Add a new item to the list/Table
    elif (strChoice.strip() == '2'):
        task = input("What TASK would you like to perform?: ")
        priority = input("What PRIORITY do you want to assign it?")
        dicNewRow = {"Task":task, "Priority":priority}
        lstTable.append(dicNewRow)
        print()
        print("!!!",task,priority, "has been added. !!!")

        continue

    # Step 5 - Remove a new item to the list/Table
    elif (strChoice == '3'):
        delItem = input("What task do you want me to delete?")
        c = 0
        while c < len(lstTable):
            if delItem in lstTable[c]["Task"]:
                del lstTable[c]
                print()
                print("!!! The task has been deleted !!!")
                print()
            c = c + 1

        continue

    # Step 6 - Save tasks to the ToDo.txt file
    elif (strChoice == '4'):
        strYN = input("Save this data to file? Y/N")
        if (strYN.lower()) == "y":
            objF = open('ToDo.txt', "w")

            for k in lstTable:
                fileTask = k.get("Task")
                filePriority = k.get("Priority")
                objF.write(str(fileTask))
                objF.write(",")
                objF.write(str(filePriority))
                objF.write("\n")
            print("!!! Table saved to file successfully !!!")
            objF.close()

        continue

    elif (strChoice == '5'):
        print("!!! Goodbye !!!")
        break  # and Exit the program
