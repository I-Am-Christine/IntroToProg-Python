#-------------------------------------------------#
# Title: Working with Functions
# Dev:   CTanner
# Date:  May 5th, 2019
# ChangeLog: (Who, When, What)
#   RRoot, 09/16/2017, (ORGINALLY) Created Script (Answer to Assignment 05)
#   CTanner, 05/05/2019, Modified for Assignment 06.py

#-------------------------------------------------#

#-- !!! DATA !!!!--#
# declare variables and constants
# objFile = An object that represents a file
# strData = A row of text data from the file
# dicRow = A row of data separated into elements of a dictionary {Task,Priority}
# lstTable = A dictionary that acts as a 'table' of rows
# strMenu = A menu of user options
# strChoice = Capture the user option selection

objFileName = "Todo.txt"
strData = ""
dicRow = {}
lstTable = []
strChoice = None
strMenu = None

#-- !!! PROCESSING !!! --#

class ToDoProcessor (object):

    # Step 1
    # When the program starts, load the any data you have
    # in a text file called ToDo.txt into a python Dictionary.
    @staticmethod
    def LoadFile():
        objFile = open(objFileName, "r")
        for line in objFile:
            strData = line.split(",") # readline() reads a line of the data into 2 elements
            dicRow = {"Task":strData[0].strip(), "Priority":strData[1].strip()}
            lstTable.append(dicRow)
        objFile.close()
        return True

    @staticmethod
    def WriteFile():
        objFile = open(objFileName, "w")
        for dicRow in lstTable:
            objFile.write(dicRow["Task"] + "," + dicRow["Priority"] + "\n")
        objFile.close()
        return True

    # Step 2
    # Display a menu of choices to the user
    @staticmethod
    def DisplayMenu():
        while (True):
            print("""
            Menu of Options
            1) Show current data
            2) Add a new item.
            3) Remove an existing item.
            4) Save Data to File
            5) Exit Program
            """)
            strChoice = str(input("Which option would you like to perform? [1 to 5] - "))
            print()  # adding a new line

            return strChoice

    # Step 3
    # Display all todo items to user

    @staticmethod
    def ShowCurrentItems():

        print("******* The current items ToDo are: *******")
        for row in lstTable:
            print(row["Task"] + "(" + row["Priority"] + ")")
        print("*******************************************")


    # Step 4
    # Add a new item to the list/Table
    @staticmethod
    def AddToList():

        strTask = str(input("What is the task? - ")).strip()
        strPriority = str(input("What is the priority? [high|low] - ")).strip()
        dicRow = {"Task":strTask,"Priority":strPriority}
        lstTable.append(dicRow)

        ToDoProcessor.ShowCurrentItems()


    # Step 5
    # Remove a new item to the list/Table
    @staticmethod
    def RemoveFromList():

        #5a-Allow user to indicate which row to delete
        strKeyToRemove = input("Which TASK would you like removed? - ")
        blnItemRemoved = False #Creating a boolean Flag
        intRowNumber = 0

        while(intRowNumber < len(lstTable)):
            if(strKeyToRemove == str(list(dict(lstTable[intRowNumber]).values())[0])): #the values function creates a list!
                del lstTable[intRowNumber]
                blnItemRemoved = True
                #end if
            intRowNumber += 1
            #end for loop

        #5b-Update user on the status
        if(blnItemRemoved == True):
            print("The task was removed.")
        else:
            print("I'm sorry, but I could not find that task.")

    # Step 6
    # Save tasks to the ToDo.txt file
    @staticmethod
    def SaveToFile():
            #6a Show the current items in the table
            ToDoProcessor.ShowCurrentItems()

            #6b Ask if they want save that data
            if("y" == str(input("Save this data to file? (y/n) - ")).strip().lower()):

                ToDoProcessor.WriteFile()

                input("Data saved to file! Press the [Enter] key to return to menu.")
            else:
                input("New data was NOT Saved, but previous data still exists! Press the [Enter] key to return to menu.")



#-- !!! DATA PRESENTATION AND I/O !!! --#

#QUESTION - SHOULD THIS LOAD FILE BE IN THE WHILE LOOP?
ToDoProcessor.LoadFile()


while (True):
    strChoice = ToDoProcessor.DisplayMenu()

    if strChoice.strip() == '1':

        ToDoProcessor.ShowCurrentItems()

        continue

    elif(strChoice.strip() == '2'):

        ToDoProcessor.AddToList()

        continue

    elif(strChoice == '3'):

        ToDoProcessor.RemoveFromList()

        continue

    elif(strChoice == '4'):

        ToDoProcessor.SaveToFile()

        continue

    elif (strChoice == '5'):
        print("!!! GOODBYE !!!")
        break


