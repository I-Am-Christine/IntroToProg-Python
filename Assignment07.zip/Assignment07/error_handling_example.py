#-------------------------------------------------#
# Title: Error Handling Example
# Dev:   CTanner
# Date:  May 11, 2019
# ChangeLog: (Who, When, What)
#   CTanner, 5/11/2019, Initial development to demonstrate
#   error handling types
#-------------------------------------------------#

#User can enter "anything
input = input("Enter in anything: ")

# With regards to "anything", the argument "None" has also been passed
# this is to ensure that we cover the "TypeError" scenario.
for value in (None,input):
    try:
        #We expect this branch of the code to work
        print("Attempting to convert", value, "-->", end=" ")
        print(float(value))
    #This branch handles invalid type of "None"
    except TypeError:
        print("I can only convert a string or a number!")
    #This branch handles value errors - meaning - it was expecting
    #a float value but a string was entered.
    except ValueError:
        print("I can only convert a string of digits")
