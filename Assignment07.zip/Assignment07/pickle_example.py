#-------------------------------------------------#
# Title: Pickle Example
# Dev:   CTanner
# Date:  May 11, 2019
# ChangeLog: (Who, When, What)
#   CTanner, 5/11/2019, Initial development to demonstrate
#   pickling
#-------------------------------------------------#

# Pickle Import module
import pickle

# Code for pickling three lists that involve attributes of
# frozen pizzas: Flavor, Brand and Size

print("Pickling lists re: Frozen Pizza!")
flavor = ["veggie", "meat lover's", "cheese"]
brand = ["DiGiorno", "Tombstone","Home Run Inn"]
size = ["personal", "standard", "hungry-man"]

# Create a new file to save all my frozen pizza data
# .dat extension means that it wil be stored in a binary
# file vs. a text file. And "wb" means it will write and
# append to a binary file
f = open("frozen_pizza.dat", "wb")

# Time to "dump" my lists into the file - or put
# my pizzas in the oven - ha, ha, ha
# and then close the file
pickle.dump(flavor, f)
pickle.dump(brand, f)
pickle.dump(size, f)
f.close()

# Read data from the file, unpickle it and display it
# to the user, "rb" means it will read binary, finally
# close the file
print("\n Unpickling the lists of Frozen Pizza!")
f = open("frozen_pizza.dat", "rb")
flavor = pickle.load(f)
brand = pickle.load(f)
size = pickle.load(f)

print(flavor)
print(brand)
print(size)
f.close()
